package com.example.janken.model

import kotlin.random.Random

enum class CardType {
    ROCK, PAPER, SCISSORS
}

data class PlayCard(val type: CardType)

class GameModel {
    private val cardUsage = mutableMapOf(CardType.ROCK to 0, CardType.PAPER to 0, CardType.SCISSORS to 0)

    fun generateAiCard(): PlayCard {
        val aiCardType = when (Random.nextInt(3)) {
            0 -> CardType.ROCK
            1 -> CardType.PAPER
            else -> CardType.SCISSORS
        }
        return PlayCard(aiCardType)
    }

    fun determineWinner(playerCard: PlayCard, aiCard: PlayCard): Int {
        return when {
            playerCard.type == aiCard.type -> 0 // Draw
            (playerCard.type == CardType.ROCK && aiCard.type == CardType.SCISSORS) ||
                    (playerCard.type == CardType.PAPER && aiCard.type == CardType.ROCK) ||
                    (playerCard.type == CardType.SCISSORS && aiCard.type == CardType.PAPER) -> 1 // Player wins
            else -> -1 // Opponent wins
        }
    }

    fun useCard(cardType: CardType): Boolean {
        return cardUsage[cardType]?.let { usage ->
            if (usage < 2) {
                cardUsage[cardType] = usage + 1
                true
            } else {
                false
            }
        } ?: false
    }

    fun resetCardUsage() {
        cardUsage.replaceAll { _, _ -> 0 }
    }
}