package com.example.janken

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.janken.model.GameViewModel
import com.example.janken.ui.theme.JankenTheme
import com.example.janken.ui.theme.RockPaperScissorsGame

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JankenTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    RockPaperScissorsGame()
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    JankenTheme {
        RockPaperScissorsGame()
    }
}

@Composable
fun StarDisplay(stars: Int) {
    Row(modifier = Modifier.padding(bottom = 8.dp)) {
        for (i in 1..stars) {
            Image(
                painter = painterResource(id = R.drawable.hosi),
                contentDescription = "Star",
                modifier = Modifier.size(24.dp),
                colorFilter = null
            )
        }
    }
}

@Composable
fun ResultDisplay(result: String?, playerStars: Int?, opponentStars: Int?, viewModel: GameViewModel, onReset: () -> Unit, onNext: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(result ?: "", fontSize = 32.sp)
        Row {
            Text("You", fontSize = 24.sp)
            StarDisplay(playerStars!!)
        }
        Row {
            Text("CPU", fontSize = 24.sp)
            StarDisplay(opponentStars!!)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Row {
            Button(onClick = { onReset() }) {
                Text("Reset")
            }
            Spacer(modifier = Modifier.width(16.dp))
            if (playerStars != null && playerStars > 0) {
                Button(onClick = { onNext() }) {
                    Text("Next Battle")
                }
            }
        }
    }
}
