package com.example.janken.model

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

class StarManager(initialStars: Int) {
    var stars by mutableStateOf(initialStars)
        private set

    fun addStar() {
        stars++
    }

    fun removeStar() {
        if (stars > 0) {
            stars--
        }
    }

    fun resetStars(initialStars: Int) {
        stars = initialStars
    }
}