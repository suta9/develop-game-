package com.example.janken.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import com.example.janken.model.GameViewModel

@Composable
fun ResultDisplay(
    result: String?,
    playerStars: Int?,
    opponentStars: Int?,
    viewModel: ViewModel,
    onReset: () -> Unit,
    onNext: () ->Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        // 結果メッセージを大きく中央に表示
        if (playerStars != null && opponentStars != null) {
            val resultText = when {
                playerStars > opponentStars -> "You Win"
                playerStars < opponentStars -> "You Lose"
                else -> "Draw"
            }
            val textColor = when {
                playerStars > opponentStars -> Color.Green
                playerStars < opponentStars -> Color.Red
                else -> Color.Black
            }
            Text(resultText, fontSize = 48.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 星の数を1箇所に表示
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("You: $playerStars", fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.width(16.dp))
            Text("CPU: $opponentStars", fontWeight = FontWeight.Bold, color = Color.White)
        }

        Spacer(modifier = Modifier.height(24.dp))

        // リセットボタンを表示
        Button(
            onClick = {
                (viewModel as? GameViewModel)?.resetGame()
                onReset()
            },
            modifier = Modifier.size(width = 150.dp, height = 60.dp) // ボタンのサイズを指定
        ) {
            Text("Reset", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 24.sp) // 24.sp に変更
        }
    }
}