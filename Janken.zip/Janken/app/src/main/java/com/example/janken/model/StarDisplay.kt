package com.example.janken.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.janken.R

@Composable
fun StarDisplay(playerStars: Int, opponentStars: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // プレイヤーの星
        Row(modifier = Modifier.padding(8.dp)) {
            Text("You", modifier = Modifier.padding(end = 8.dp), color = Color.White) // プレイヤーの名前を表示, 文字色を白色に変更
            for (i in 1..playerStars) {
                Image(
                    painter = painterResource(id = R.drawable.hosi),
                    contentDescription = "Player Star",
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // CPUの星
        Row(modifier = Modifier.padding(8.dp)) {
            for (i in 1..opponentStars) {
                Image(
                    painter = painterResource(id = R.drawable.hosi),
                    contentDescription = "CPU Star",
                    modifier = Modifier.size(24.dp)
                )
            }
            Text("CPU", modifier = Modifier.padding(start = 8.dp), color = Color.White) // CPUの名前を右側に表示, 文字色を白色に変更
        }
    }
}