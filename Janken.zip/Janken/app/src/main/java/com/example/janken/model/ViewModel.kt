package com.example.janken.model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class GameViewModel : ViewModel() {
    private val model = GameModel()
    private val _aiCard = MutableLiveData<PlayCard?>()
    val aiCard: LiveData<PlayCard?> = _aiCard
    private val _result = MutableLiveData<String?>("")
    val result: LiveData<String?> = _result
    val playerStarsManager = StarManager(3)
    val opponentStarsManager = StarManager(3)
    private val _isGameOver = MutableLiveData(false)
    val isGameOver: LiveData<Boolean> = _isGameOver

    fun onCardSelected(playerCard: PlayCard) {
        if (_isGameOver.value == true) return
        val aiCard = model.generateAiCard()
        val winner = model.determineWinner(playerCard, aiCard)
        if (winner == 1) {
            opponentStarsManager.removeStar()
            playerStarsManager.addStar()
        } else if (winner == -1) {
            playerStarsManager.removeStar()
            opponentStarsManager.addStar()
        }
        _aiCard.value = aiCard
        val resultMessage = when (winner) {
            1 -> "You Win"
            -1 -> "You Lose"
            else -> "Draw"
        }
        _result.value = resultMessage
        if (playerStarsManager.stars == 0 || opponentStarsManager.stars == 0) {
            _isGameOver.value = true
            _result.value = if (playerStarsManager.stars == 0) "CPU Win" else "You Win"
        }
        model.useCard(playerCard.type) // カードの使用回数を更新
    }

    fun resetGame() {
        playerStarsManager.resetStars(3)
        opponentStarsManager.resetStars(3)
        _isGameOver.value = false
        _result.value = null
        model.resetCardUsage() // カードの使用回数をリセット
    }

    fun nextGame() {
        _isGameOver.value = false
        _result.value = null
        model.resetCardUsage() // カードの使用回数をリセット
    }

    fun updataresult(newString: String) {
        _result.value = newString
    }
}