package com.example.janken.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.janken.R
import com.example.janken.model.CardType
import com.example.janken.model.GameViewModel
import com.example.janken.model.PlayCard
import androidx.compose.ui.layout.ContentScale

@Composable
fun RockPaperScissorsGame(viewModel: GameViewModel = viewModel()) {
    val rockCard = remember { PlayCard(CardType.ROCK) }
    val paperCard = remember { PlayCard(CardType.PAPER) }
    val scissorsCard = remember { PlayCard(CardType.SCISSORS) }

    var selectedCard by remember { mutableStateOf<PlayCard?>(null) }
    val aiCard by viewModel.aiCard.observeAsState()
    val result by viewModel.result.observeAsState()
    val isGameOver by viewModel.isGameOver.observeAsState()
    var cardUsage by remember { mutableStateOf(mutableMapOf(rockCard to 2, paperCard to 2, scissorsCard to 2)) }
    var showResult by remember { mutableStateOf(false) }

    val playerStarsManager = viewModel.playerStarsManager
    val opponentStarsManager = viewModel.opponentStarsManager

    Scaffold(containerColor = Color.Transparent) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize()) {
            BackgroundImage() // 背景画像を表示
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 結果発表画面でのみ Result をタイトル位置に表示
                if (showResult && result != null) {
                    Text(result!!, fontSize = 36.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp), color = Color.White) // 36.sp に変更
                } else {
                    Text(
                        "Gentei Janken",
                        fontSize = 36.sp, // 文字サイズを 36.sp に変更
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 16.dp),
                        color = Color.White
                    )
                }

                // 勝負中の Result 表示を削除
                // if (result != null && !showResult) {
                //     Text(result, fontWeight = FontWeight.Bold, color = Color.White)
                //     Spacer(modifier = Modifier.height(8.dp))
                // }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    StarDisplay(playerStarsManager.stars, opponentStarsManager.stars)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CardColumn(rockCard, viewModel, cardUsage, selectedCard == rockCard) {
                        if (cardUsage[rockCard]!! > 0) {
                            selectedCard = rockCard
                        } else {
                            viewModel.updataresult("カードがありません")
                        }
                    }
                    CardColumn(paperCard, viewModel, cardUsage, selectedCard == paperCard) {
                        if (cardUsage[paperCard]!! > 0) {
                            selectedCard = paperCard
                        } else {
                            viewModel.updataresult("カードがありません")
                        }
                    }
                    CardColumn(scissorsCard, viewModel, cardUsage, selectedCard == scissorsCard) {
                        if (cardUsage[scissorsCard]!! > 0) {
                            selectedCard = scissorsCard
                        } else {
                            viewModel.updataresult("カードがありません")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (selectedCard != null) {
                            val selectedCardType = selectedCard!!
                            val selectedCardUsage = cardUsage[selectedCardType]
                            if (selectedCardUsage != null && selectedCardUsage > 0) {
                                viewModel.onCardSelected(selectedCard!!)
                                selectedCard = null
                                cardUsage = cardUsage.toMutableMap().apply {
                                    this[selectedCardType] = selectedCardUsage - 1
                                }
                                if (cardUsage.values.sum() == 0 || playerStarsManager.stars == 0 || opponentStarsManager.stars == 0) {
                                    showResult = true
                                }
                            } else {
                                viewModel.updataresult("カードがありません")
                            }
                        }
                    },
                    enabled = selectedCard != null && isGameOver == false && !showResult,
                    modifier = Modifier.size(width = 150.dp, height = 60.dp) // ボタンのサイズを指定
                ) {
                    Text("Battle", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 24.sp) // 24.sp に変更
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (showResult) {
                    ResultDisplay(result, playerStarsManager.stars, opponentStarsManager.stars, viewModel, onReset = {
                        cardUsage = mutableMapOf(rockCard to 2, paperCard to 2, scissorsCard to 2)
                        showResult = false
                        viewModel.resetGame()
                    }, onNext = {
                        cardUsage = mutableMapOf(rockCard to 2, paperCard to 2, scissorsCard to 2)
                        showResult = false
                    })
                }

                if (result != null && isGameOver == false && !showResult) {
                    Text(result!!, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun CardColumn(card: PlayCard, viewModel: GameViewModel, cardUsage: MutableMap<PlayCard, Int>, isSelected: Boolean, onCardClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        CardImage(card, cardUsage[card] ?: 0, isSelected, onCardClick)
        Text("x${cardUsage[card]}", fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable
fun CardImage(card: PlayCard, cardUsage: Int, isSelected: Boolean, onCardClicked: () -> Unit) {
    val image = when (card.type) {
        CardType.ROCK -> R.drawable.c
        CardType.PAPER -> R.drawable.b
        CardType.SCISSORS -> R.drawable.a
    }
    Card(
        modifier = Modifier
            .size(120.dp)
            .clickable(enabled = cardUsage > 0) {
                onCardClicked()
            },
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = image),
                contentDescription = card.type.toString(),
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}